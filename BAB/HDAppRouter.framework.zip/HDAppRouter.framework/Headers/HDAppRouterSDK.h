//
//  HDAppRouterSDK.h
//  HDAppRouter
//
//  Created by GaoAng on 2019/9/26.
//  Copyright © 2019 com.evergrande. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class HDARGetAuthCodeReq, HDARCheckAuthCodeReq;
@interface HDAppRouterSDK : NSObject


/*! @brief SDK 初始化方法
*
* 需要在引入SDK后调用。
* @appId  调用方的APPID
* @appKey  APP唯一识别
* @return 成功返回YES，失败返回NO。
*/
+ (BOOL)initSDKWithAppID:(nonnull NSString*)appId appkey:(nonnull NSString*)appKey;

/*
 ! @brief  获取第三方应用的授权码
*/
+ (void)getAuthCodeWithReq:(HDARGetAuthCodeReq*_Nonnull)req completionHandler:(void(^ _Nullable )(BOOL isOpenApp, NSDictionary * _Nullable responseDic, NSError * _Nullable error))completionHandler;


/*
 ! @brief  第三方应用校验授权码
*/

+ (void)checkAuthCodeWithReq:(HDARCheckAuthCodeReq*_Nonnull)req completionHandler:(void(^ _Nullable )(NSDictionary * _Nonnull responseDic, NSError * _Nonnull error))completionHandler;


/*
 ! @brief  打开指定的H5 页面
*/
+ (void)openWebViewWithURL:(NSString *_Nonnull)url withNavigation:(UINavigationController*_Nonnull)nav;


//对传入的字符 加密。
+ (NSString*_Nonnull)encodeAccessToken:(NSString* _Nonnull)acceCode;



//对传入的字符 加密。
+ (NSString*_Nonnull)decodeAccessToken:(NSString*_Nonnull)acceCode;


@end

