//
//  HDAppRouter.h
//  HDAppRouter
//
//  Created by GaoAng on 2019/9/26.
//  Copyright © 2019 com.evergrande. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for HDAppRouter.
FOUNDATION_EXPORT double HDAppRouterVersionNumber;

//! Project version string for HDAppRouter.
FOUNDATION_EXPORT const unsigned char HDAppRouterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HDAppRouter/PublicHeader.h>
#import "HDAppRouterSDK.h"
#import "HDARRequestData.h"

