//
//  HDARGetAuthCodeReq.h
//  HDAppRouter
//
//  Created by GaoAng on 2019/9/26.
//  Copyright © 2019 com.evergrande. All rights reserved.
//

#import <Foundation/Foundation.h>


/*
 *  获取第三方应用的授权码
 */
@interface HDARGetAuthCodeReq : NSObject

@property (nonatomic, copy)  NSString *access_token;

@property (nonatomic, copy)  NSString *union_id;

@property (nonatomic, copy)  NSString *channel_id;

@property (nonatomic, copy)  NSString *urlScheme;

@end

/*
 *  第三方应用校验授权码
 */
@interface HDARCheckAuthCodeReq : NSObject

@property (nonatomic, copy)  NSString *auth_code;
@property (nonatomic, copy)  NSString *union_id;

@end
